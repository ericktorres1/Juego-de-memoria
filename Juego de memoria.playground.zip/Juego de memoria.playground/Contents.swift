//: Playground - noun: a place where people can play
// Erick Torres
// Swift: programar para iOS by Tecnologico de Monterrey

import UIKit


var rango =  0...100

for numero in rango {
    
    if numero >= 30 && numero <= 40
    {
        print("#\(numero) \"Viva Swift\"")
    }
    
    if numero % 5 == 0
    {
        print("#\(numero) \"Bingo!!!\"")
        if numero % 2 != 0 && numero != 0
        {
            print ("#\(numero) \"impar!!!\"")
        } else if numero % 2 == 0  && numero != 0
        {
            print("#\(numero) \"par!!!\"")
        }
    } else if numero % 2 != 0 {
        print("#\(numero) \"impar!!!\"")
    } else if numero % 2 == 0 {
        print("#\(numero) \"par!!!\"")
    }
}
    


